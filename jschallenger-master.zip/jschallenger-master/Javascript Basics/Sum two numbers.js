// Write a function that takes two numbers (a and b) as argument
// Sum a and b
// Return the result

function myFunction(a, b) {
  return a + b
}
