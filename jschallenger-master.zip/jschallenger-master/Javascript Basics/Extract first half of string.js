// Write a function that takes a string (a) as argument
// Extract the first half a
// Return the result

function myFunction(a) {
  return a.slice(a.count / 2)
}
