// Write a function that takes a value as argument
// Return the type of the value

function myFunction(a) {
  return typeof a
}
