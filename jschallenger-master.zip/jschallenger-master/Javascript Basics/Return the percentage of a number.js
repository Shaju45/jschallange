// Write a function that takes an object with the properties number and percentage as argument
// Return the given percentage of the number

function myFunction({ number, percentage }) {
  return number * percentage / 100
}
