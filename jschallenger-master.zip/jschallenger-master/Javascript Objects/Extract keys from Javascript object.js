// Write a function that takes an object (a) as argument
// Return an array with all object keys

function myFunction(a) {
  return Object.keys(a)
}
