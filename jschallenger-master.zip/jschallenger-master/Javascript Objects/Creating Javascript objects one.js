// Write a function that a string (a) as argument
// Create an object that has a property with key 'key' and a value of a
// Return the object

function myFunction(a) {
  return { key: a }
}
