// Sounds easy, but you need to know the trick
// Write a function that takes two date instances as argument
// It should return true if the dates are equal
// It should return false otherwise

function myFunction(d1, d2) {
  return d1.getTime() === d2.getTime()
}
