// Write a function that takes an array (a) as argument
// Return the number of elements in a

function myFunction(a) {
  return a.length
}
