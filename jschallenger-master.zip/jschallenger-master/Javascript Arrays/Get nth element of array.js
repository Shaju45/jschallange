// Write a function that takes an array (a) and a value (n) as argument
// Return the nth element of 'a'

function myFunction(a, n) {
  return a[n - 1]
}
