// Write a function that takes an array of strings as argument
// It should return the array with its values sorted alphabetically

function myFunction(arr) {
  return arr.sort()
}
