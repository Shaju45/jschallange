const button = document.getElementById('button');
button.addEventListener('click', () => {
  // type in your code here
  document.getElementById('checkbox').checked = true
});
